class userControllers{
    constructor(formId){
        //Manipulação do formulário
        this.formId = document.getElementById(formId); 
    }
    // Metódo de evento de click
    onSubmit(){
        this.formId.getElementById("form-user-create").addEventListener("submit",function(event){
            event.preventDefault();
            this.getValues();
        });    
    }
    // carrega valores dos inputs
    getValues(){
        let user = {};
        /**
         * Esse elements depois do this.formId é um array de 9 posições dentro 
         * do objeto do formulário, contendo todos os inputs. Qualquer coisa 
         * abra o console e digite -> dir(document.getElementById(form-user-create))
         *  e procure por elements
        */
        this.formId.elements.forEach(function(field){

            if(field.name == "gender" ){
                if( field.checked==true){
                    user[field.name] = field.value;
                }
            }   
            else{
                user[field.name] = field.value;
            }   
        });

        event.preventDefault();
        //comunicação com classe User() do arquivo users.js;
         return new User(user.name,
            user.gender,
            user.date,
            user.country,
            user.email,
            user.password,
            user.photo,
            user.admin 
        );

        addLineUser(user);
    }
}