// essa classe cuida somente dos dados
class User{
                    // essas info são objetos
    constructor(name,gender,date,country,email,password,photo,admin){
        this.name=name;
        this.date=date;
        this.gender=gender;
        this.country=country;
        this.email=email;
        this.password=password;
        this.photo=photo;
        this.admin=admin;
        

    }
}