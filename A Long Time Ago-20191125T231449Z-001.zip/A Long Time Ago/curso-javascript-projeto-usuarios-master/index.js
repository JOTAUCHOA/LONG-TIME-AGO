
// o atributo name traz todos os inputs que tenha o atributo name. Se colocar um sinal de igual é especificar o elemento 
// só virá um.
var fields = document.querySelectorAll("#form-user-create [name]");
// Foi criado um array cde inputs do formulário
var user = {};
function addLineUser(dataUser){
    document.getElementById("table-users").innerHTML = `<tr>
                <td></td>
                <td>${dataUser.name}</td>
                <td>${dataUser.email}</td>
                <td>${dataUser.admin}</td>
                <td>${dataUser.birth}</td>
                <td>
                <button type="button" class="btn btn-primary btn-xs btn-flat">Editar</button>
                <button type="button" class="btn btn-danger btn-xs btn-flat">Excluir</button>
                </td>
            </tr>`

    
}

document.getElementById("form-user-create").addEventListener("submit",function(event){
    
    fields.forEach(function(field){

        if(field.name == "gender" ){
            if( field.checked==true){
                user[field.name] = field.value;
            }
        }   
        else{
            user[field.name] = field.value;
        }   
    });
    event.preventDefault();
    //comunicação com classe User() do arquivo users.js;
     var objectUserInfos = new User(user.name,
        user.gender,
        user.date,
        user.country,
        user.email,
        user.password,
        user.photo,
        user.admin );
    addLineUser(user);
});


