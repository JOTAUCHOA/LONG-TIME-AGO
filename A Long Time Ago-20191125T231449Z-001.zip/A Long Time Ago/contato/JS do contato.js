function validar(){
	nome=document.getElementById('nome').value;
	email=document.getElementById('email').value;
		try{
			if(nome==""){
				throw "Inisira o nome";
			}
			if(email.include!==('@')&& email.include!===('.com') || email==""){
				throw "insira um email valido";
				document.getElementById('msg').style.color="red";
			}
		}
		catch(msg){
			label.innerHTML=msg;
			
		}
}

